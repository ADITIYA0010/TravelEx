const express = require('express');
const router = express.Router();
const Expense = require('../models/Expense');
const TravelRequest = require('../models/TravelRequest');
const User = require('../models/User');

// Middleware to ensure employee role (assumes req.user is set by auth middleware)
function requireEmployee(req, res, next) {
  if (!req.user || (req.user.role.toLowerCase() !== 'employee' && req.user.role.toLowerCase() !== 'user')) {
    return res.status(403).json({ success: false, message: 'Access denied: Employees only' });
  }
  next();
}

// GET /api/employee/expenses - List all expenses for this employee
router.get('/expenses', requireEmployee, async (req, res) => {
  try {
    const expenses = await Expense.find({ employee: req.user._id }).sort({ date: -1 });
    res.json({ success: true, data: expenses });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// GET /api/employee/travel-requests - List all travel requests for this employee
router.get('/travel-requests', requireEmployee, async (req, res) => {
  try {
    const travelRequests = await TravelRequest.find({ employee: req.user._id }).sort({ start: -1 });
    res.json({ success: true, data: travelRequests });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// POST /api/employee/expenses - Submit a new expense
router.post('/expenses', requireEmployee, async (req, res) => {
  try {
    const { amount, category, date, notes } = req.body;
    const expense = new Expense({
      employee: req.user._id,
      amount,
      category,
      date: date ? new Date(date) : new Date(),
      status: 'Pending',
      notes
    });
    await expense.save();
    res.status(201).json({ success: true, data: expense });
  } catch (err) {
    res.status(400).json({ success: false, message: 'Could not create expense', error: err.message });
  }
});

// POST /api/employee/travel-requests - Submit a new travel request
router.post('/travel-requests', requireEmployee, async (req, res) => {
  try {
    const { destination, start, end, purpose } = req.body;
    const travelRequest = new TravelRequest({
      employee: req.user._id,
      destination,
      start: new Date(start),
      end: new Date(end),
      purpose,
      status: 'Pending'
    });
    await travelRequest.save();
    res.status(201).json({ success: true, data: travelRequest });
  } catch (err) {
    res.status(400).json({ success: false, message: 'Could not create travel request', error: err.message });
  }
});

module.exports = router;
