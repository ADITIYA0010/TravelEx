const mongoose = require('mongoose');

const expenseSchema = new mongoose.Schema({
  employee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  category: { type: String, enum: ['Meals', 'Transport', 'Lodging', 'Entertainment', 'Other'], required: true },
  date: { type: Date, required: true },
  status: { type: String, enum: ['Pending', 'Approved', 'Rejected', 'Reimbursed'], default: 'Pending' },
  attachments: [{ type: String }], // file URLs or paths
  comments: [{ body: String, date: Date, by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' } }],
  reimbursed: { type: Boolean, default: false },
  policyViolation: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Expense', expenseSchema);
