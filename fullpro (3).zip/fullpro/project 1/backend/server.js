const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const connectDB = require('./config/db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

connectDB();

app.use('/api/auth', require('./routes/auth'));

// JWT authentication middleware for protected routes
const authMiddleware = require('./middleware/authMiddleware');
app.use('/api/manager', authMiddleware, require('./routes/manager'));
app.use('/api/employee', authMiddleware, require('./routes/employee'));

const http = require('http');
const { Server } = require('socket.io');

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  console.log('A client connected:', socket.id);
});

server.listen(3001, () => {
  console.log('Server running with WebSocket on http://localhost:3001');
});

module.exports = io;